package com.mahesh.ecomsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EcomsystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(EcomsystemApplication.class, args);
	}

}
